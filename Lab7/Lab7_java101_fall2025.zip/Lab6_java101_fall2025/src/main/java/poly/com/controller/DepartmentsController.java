package poly.com.controller;

import java.io.IOException;
import java.util.List;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import poly.com.dao.DepartmentsDao;
import poly.com.model.Departments;
@WebServlet({"/Departments","/Departments/loadall","/Departments/add","/Departments/delete","/Departments/find","/Departments/update", "/Departments/edit"})
public class DepartmentsController extends HttpServlet{ 
	    protected void deleteDepartments(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	           
	        String idToDelete = request.getParameter("id");
	        // Gọi DAO để xóa
	        DepartmentsDao.deleteDepartment(idToDelete);	      	     
	    }
	    
	    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	        // TODO Auto-generated method stub
	        String uri = req.getRequestURI();
	        String id = req.getParameter("id");
	        String name = req.getParameter("name");
	        String description = req.getParameter("description");

	        if (uri.contains("add"))
	        {
	            Departments dept = new Departments(id, name, description);
	            DepartmentsDao.insert(dept);
	        } 
	        else if (uri.contains("update")) {
	            Departments dept = new Departments(id, name, description);
	            DepartmentsDao.update(dept);
	            System.out.println("Cập nhật thành công!");
	        } 
	        else if (uri.contains("delete"))
	        {
	            DepartmentsDao.deleteDepartment(id);
	            System.out.println("Xóa thành công!");
	        } 
	        else if (uri.contains("find"))
	        {
	            Departments dept = DepartmentsDao.findDepartmentById1(req.getParameter("txttim"));
	            if (dept != null) {
	                req.setAttribute("departmentEdit", dept);
	            }
	        }
	        List<Departments> list = DepartmentsDao.selectAll();
	        req.setAttribute("departments", list);
	        req.getRequestDispatcher("/Departments/DepartmentsGui.jsp").forward(req, resp);
	        // Sau khi xử lý xong → load danh sách
	    }
	    
	    @Override
	    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	        String uri = req.getRequestURI();
	        DepartmentsDao dao = new DepartmentsDao();


	        if (uri.contains("edit"))
	        {
	            // Lấy id từ URL
	            String idStr = req.getParameter("id");
	            if (idStr != null)
	            {
	                // Tìm phòng ban theo id
	                Departments dept = dao.findDepartmentById1(idStr);

	                // Gửi thông tin phòng ban lên JSP để hiển thị trong form
	                req.setAttribute("departmentEdit", dept);
	            }
	        }
	        else
		        if(uri.contains("delete"))
		        {
		            deleteDepartments(req, resp);
		        }

		    // Load toàn bộ danh sách để hiển thị bảng
	        List<Departments> list = DepartmentsDao.selectAll();
	        req.setAttribute("departments", list);
	        req.getRequestDispatcher("/Departments/DepartmentsGui.jsp").forward(req, resp);

		    
	    }
}
		    