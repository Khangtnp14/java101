package poly.com.dao;

import java.sql.Connection;
import java.sql.DriverManager;

public class Connectdao {
	
	protected static Connection conn; 
	public Connectdao() {
	
		try { 
			String url = "jdbc:sqlserver://localhost:1433;databaseName=Lab6_java101_fall2025";
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			conn = DriverManager.getConnection(url, "sa", "");
			System.out.println("Kết nối thành công");
		}
		catch (Exception ex) {
			ex.printStackTrace();
		}
	}
	
	
	
	
	
	
	
	
	
	
	
	
}
