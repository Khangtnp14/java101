package poly.com.dao;

public class Maintestdao {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		DepartmentsDao Dedao = new DepartmentsDao();
	
		//Dedao.insertDepartment("004", "IT", "Phòng IT");
	
		//Dedao.deleteDepartment("004");
		//Dedao.updateDepartment("001", "IT ok", "Phòng IT");
		//Dedao.findDepartmentById("001");
		//Dedao.addDepartmentStore("002", "Đàm Vĩnh Hưng", "Phòng IT");
		Dedao.printAllDepartments();
	}

}
 