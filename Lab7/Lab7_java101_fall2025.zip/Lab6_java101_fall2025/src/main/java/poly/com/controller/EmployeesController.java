package poly.com.controller;

import java.io.File;
import java.io.IOException;
import java.nio.file.Paths;
import java.sql.Date;
import java.text.NumberFormat;
import java.text.ParseException;
import java.util.List;
import java.util.Locale;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import jakarta.servlet.http.Part;

import poly.com.dao.EmployeesDao;
import poly.com.model.Employees;

@MultipartConfig(
    fileSizeThreshold = 1024 * 1024,      // 1MB
    maxFileSize       = 1024 * 1024 * 10, // 10MB
    maxRequestSize    = 1024 * 1024 * 20  // 20MB
)
@WebServlet({
    "/Employees", "/Employees/add", "/Employees/update",
    "/Employees/delete", "/Employees/edit", "/Employees/find"
})
public class EmployeesController extends HttpServlet {
    private final EmployeesDao dao = new EmployeesDao();

    // --- helpers ---
    private Date parseSqlDate(String s) {
        if (s == null || s.isBlank()) return null; // yyyy-MM-dd
        return Date.valueOf(s.trim());
    }

    private double parseSalary(String s) {
        if (s == null || s.isBlank()) return 0;
        s = s.trim();
        try {
            Number n = NumberFormat.getInstance(new Locale("vi", "VN")).parse(s);
            return n.doubleValue();
        } catch (ParseException ignore) {}
        String normalized = s.replace(" ", "").replace(".", "").replace(",", ".");
        try { return Double.parseDouble(normalized); }
        catch (NumberFormatException e) { return 0; }
    }

    private boolean parseGender(String g) {
        if (g == null) return false;
        g = g.trim();
        return "true".equalsIgnoreCase(g) || "nam".equalsIgnoreCase(g) || "1".equals(g);
    }

    private void goList(HttpServletRequest req, HttpServletResponse resp)
            throws IOException, ServletException {
        List<Employees> list = dao.selectAll();
        req.setAttribute("employees", list);
        req.getRequestDispatcher("/Departments/EmployeesGui.jsp").forward(req, resp);
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        String uri = req.getRequestURI();

        if (uri.contains("edit")) {
            String id = req.getParameter("id");
            if (id != null) req.setAttribute("employeeEdit", dao.findById(id));
            goList(req, resp);
            return;
        }

        if (uri.contains("delete")) {
            String id = req.getParameter("id");
            if (id != null) dao.delete(id);
            resp.sendRedirect(req.getContextPath() + "/Employees"); // PRG
            return;
        }

        goList(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        String uri = req.getRequestURI();

        // lấy form (fields text)
        String id           = req.getParameter("id");
        String password     = req.getParameter("password");
        String fullname     = req.getParameter("fullname");
        boolean gender      = parseGender(req.getParameter("gender"));
        Date birthday       = parseSqlDate(req.getParameter("birthday"));
        double salary       = parseSalary(req.getParameter("salary"));
        String departmentId = req.getParameter("departmentId");

        // xử lý tìm kiếm
        if (uri.contains("find")) {
            Employees f = dao.findById(req.getParameter("txttim"));
            if (f != null) req.setAttribute("employeeEdit", f);
            goList(req, resp);
            return;
        }

        // ==== XỬ LÝ UPLOAD ẢNH ====
        String photoPath = null; // đường dẫn sẽ lưu vào DB (ví dụ: uploads/abc.png)
        Part photoPart = req.getPart("photoFile"); // name="photoFile" từ JSP
        if (photoPart != null && photoPart.getSize() > 0) {
            // thư mục vật lý /uploads trong webapp
            String uploadDir = getServletContext().getRealPath("/uploads");
            new File(uploadDir).mkdirs();

            String submitted = Paths.get(photoPart.getSubmittedFileName()).getFileName().toString();
            String ext = "";
            int dot = submitted.lastIndexOf('.');
            if (dot >= 0) ext = submitted.substring(dot);
            String safeName = id + "_" + System.currentTimeMillis() + ext;

            File dest = new File(uploadDir, safeName);
            photoPart.write(dest.getAbsolutePath());       // lưu file

            photoPath = "uploads/" + safeName;             // đường dẫn web để hiển thị
        }

        // Nếu UPDATE mà không upload ảnh mới -> giữ ảnh cũ
        if (uri.contains("update") && (photoPath == null || photoPath.isBlank())) {
            Employees old = dao.findById(id);
            if (old != null) photoPath = old.getPhoto();
        }
        // Nếu ADD mà không có ảnh -> để rỗng
        if (photoPath == null) photoPath = "";

        Employees e = new Employees(id, password, fullname, photoPath, gender, birthday, salary, departmentId);

        if (uri.contains("add"))    dao.insert(e);
        if (uri.contains("update")) dao.update(e);
        if (uri.contains("delete")) dao.delete(id);

        resp.sendRedirect(req.getContextPath() + "/Employees"); // PRG
    }
}
