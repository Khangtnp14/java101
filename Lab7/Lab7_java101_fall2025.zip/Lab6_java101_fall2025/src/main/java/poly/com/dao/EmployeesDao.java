package poly.com.dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import poly.com.model.Employees;

public class EmployeesDao extends Connectdao {

    public int countAll() {
        String sql = "SELECT COUNT(*) FROM dbo.Employees";
        try (PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            rs.next();
            return rs.getInt(1);
        } catch (Exception ex) {
            System.out.println("[DAO] countAll() error:");
            ex.printStackTrace();
            return -1;
        }
    }

    public List<Employees> selectAll() {
        List<Employees> list = new ArrayList<>();
        String sql = "SELECT Id, Password, Fullname, Photo, Gender, Birthday, Salary, DepartmentId FROM dbo.Employees";
        try (PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                Employees e = new Employees();
                e.setId(rs.getString("Id"));
                e.setPassword(rs.getString("Password"));
                e.setFullname(rs.getString("Fullname"));
                e.setPhoto(rs.getString("Photo"));
                e.setGender(rs.getBoolean("Gender"));
                e.setBirthday(rs.getDate("Birthday"));     // java.sql.Date
                e.setSalary(rs.getDouble("Salary"));
                e.setDepartmentId(rs.getString("DepartmentId"));
                list.add(e);
            }
            System.out.println("[DAO] selectAll -> " + list.size() + " rows");
        } catch (Exception ex) {
            System.out.println("[DAO] selectAll() error:");
            ex.printStackTrace();
        }
        return list;
    }

    public Employees findById(String id) {
        String sql = "SELECT * FROM dbo.Employees WHERE Id=?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    Employees e = new Employees();
                    e.setId(rs.getString("Id"));
                    e.setPassword(rs.getString("Password"));
                    e.setFullname(rs.getString("Fullname"));
                    e.setPhoto(rs.getString("Photo"));
                    e.setGender(rs.getBoolean("Gender"));
                    e.setBirthday(rs.getDate("Birthday"));
                    e.setSalary(rs.getDouble("Salary"));
                    e.setDepartmentId(rs.getString("DepartmentId"));
                    return e;
                }
            }
        } catch (Exception ex) {
            System.out.println("[DAO] findById() error:");
            ex.printStackTrace();
        }
        return null;
    }

    public int insert(Employees e) {
        String sql = "INSERT INTO dbo.Employees (Id,Password,Fullname,Photo,Gender,Birthday,Salary,DepartmentId) "
                   + "VALUES (?,?,?,?,?,?,?,?)";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, e.getId());
            ps.setString(2, e.getPassword());
            ps.setString(3, e.getFullname());
            ps.setString(4, e.getPhoto());
            ps.setBoolean(5, e.isGender());
            if (e.getBirthday() == null) ps.setNull(6, Types.DATE); else ps.setDate(6, e.getBirthday());
            ps.setDouble(7, e.getSalary());
            ps.setString(8, e.getDepartmentId());
            return ps.executeUpdate();
        } catch (Exception ex) {
            System.out.println("[DAO] insert() error:");
            ex.printStackTrace();
            return 0;
        }
    }

    public int update(Employees e) {
        String sql = "UPDATE dbo.Employees SET Password=?, Fullname=?, Photo=?, Gender=?, "
                   + "Birthday=?, Salary=?, DepartmentId=? WHERE Id=?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, e.getPassword());
            ps.setString(2, e.getFullname());
            ps.setString(3, e.getPhoto());
            ps.setBoolean(4, e.isGender());
            if (e.getBirthday() == null) ps.setNull(5, Types.DATE); else ps.setDate(5, e.getBirthday());
            ps.setDouble(6, e.getSalary());
            ps.setString(7, e.getDepartmentId());
            ps.setString(8, e.getId());
            return ps.executeUpdate();
        } catch (Exception ex) {
            System.out.println("[DAO] update() error:");
            ex.printStackTrace();
            return 0;
        }
    }

    public int delete(String id) {
        String sql = "DELETE FROM dbo.Employees WHERE Id=?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, id);
            return ps.executeUpdate();
        } catch (Exception ex) {
            System.out.println("[DAO] delete() error:");
            ex.printStackTrace();
            return 0;
        }
    }
}
