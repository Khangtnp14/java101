package poly.com.model;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import poly.com.model.Product;

@WebServlet("/Lab3bai5")
public class Lab3Bai5Controller extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) 
            throws ServletException, IOException {
        
    	List<Product> list = new ArrayList<>();
    	list.add(new Product("SP01", "iPhone 17 Pro Max 1TB", 50990000, "images/17.jpg"));
    	list.add(new Product("SP02", "Samsung Galaxy S25 Ultra 1TB", 35490000, "images/ss.jpg"));
    	list.add(new Product("SP03", "MacBook Air M4", 39990000, "images/macm4.jpg"));
    	list.add(new Product("SP04", "AirPods Pro 3", 6690000, "images/pro3.jpg"));
    	list.add(new Product("SP05", "Apple Watch Ultra 3", 26990000, "images/apple.jpg"));
    	list.add(new Product("SP06", "iPad Pro M5", 45590000, "images/ipad.png"));

        req.setAttribute("danhsach", list);
        req.getRequestDispatcher("/Lab3bai5.jsp").forward(req, resp);
    }
}
