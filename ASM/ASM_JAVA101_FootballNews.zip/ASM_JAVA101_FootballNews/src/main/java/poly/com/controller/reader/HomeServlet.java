package poly.com.controller.reader;

import java.io.IOException;
import java.util.List;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import poly.com.dao.CategoryDao;
import poly.com.dao.NewsDao;
import poly.com.model.Category;
import poly.com.model.News;

@WebServlet("/home")
public class HomeServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        // =========================================================
        // (1) i18n: nhận lang từ URL và lưu vào session
        //     VD: /home?lang=vi  hoặc /home?lang=en
        //     -> KHÔNG đè file tiếng Việt, chỉ lưu biến session "lang"
        // =========================================================
        String lang = req.getParameter("lang");
        if (lang != null) {
            lang = lang.trim().toLowerCase();
            // Chỉ cho phép 2 giá trị để tránh lỗi lung tung
            if (!"vi".equals(lang) && !"en".equals(lang)) {
                lang = "vi";
            }
            req.getSession().setAttribute("lang", lang);
        }

        // Nếu chưa chọn ngôn ngữ lần nào -> mặc định vi
        if (req.getSession().getAttribute("lang") == null) {
            req.getSession().setAttribute("lang", "vi");
        }

        // =========================================================
        // (2) Load dữ liệu trang chủ như bạn đang làm
        // =========================================================
        try {
            CategoryDao cdao = new CategoryDao();
            NewsDao ndao = new NewsDao();

            List<Category> cates = cdao.findAll();
            List<News> homeList  = ndao.findHome();
            List<News> hotList   = ndao.findHotTop5();
            List<News> latestList= ndao.findLatestTop5();

            req.setAttribute("cates", cates);
            req.setAttribute("homeList", homeList);
            req.setAttribute("hotList", hotList);
            req.setAttribute("latestList", latestList);

            req.getRequestDispatcher("/reader/home.jsp").forward(req, resp);
        } catch (Exception e) {
            e.printStackTrace();
            resp.sendError(500);
        }
    }
}
