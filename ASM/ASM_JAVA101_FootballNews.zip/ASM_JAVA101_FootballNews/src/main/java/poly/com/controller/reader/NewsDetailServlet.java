package poly.com.controller.reader;

import java.io.IOException;
import java.util.List;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import poly.com.dao.CategoryDao;
import poly.com.dao.NewsDao;
import poly.com.model.Category;
import poly.com.model.News;

@WebServlet("/news/detail")
public class NewsDetailServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        String sid = req.getParameter("id");
        if (sid == null) { resp.sendRedirect(req.getContextPath() + "/home"); return; }

        try {
            int id = Integer.parseInt(sid);
            NewsDao ndao = new NewsDao();
            CategoryDao cdao = new CategoryDao();

            News news = ndao.findById(id);
            if (news == null) { resp.sendRedirect(req.getContextPath() + "/home"); return; }

            ndao.increaseView(id);
            news.setViewCount(news.getViewCount() + 1);

            List<Category> cates = cdao.findAll();
            List<News> related = ndao.findRelated(id, news.getCategoryId());

            req.setAttribute("news", news);
            req.setAttribute("cates", cates);
            req.setAttribute("related", related);

            req.getRequestDispatcher("/reader/detail.jsp").forward(req, resp);
        } catch (Exception e) {
            e.printStackTrace();
            resp.sendError(500);
        }
    }
}
