package poly.com.controller.reporter;

import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import poly.com.dao.UserDao;
import poly.com.model.User;

@WebServlet("/reporter/login")
public class ReporterLoginServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        req.getRequestDispatcher("/reporter/login.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        String id = req.getParameter("id");
        String pw = req.getParameter("password");

        try {
            UserDao dao = new UserDao();
            User u = dao.login(id, pw);
            if (u != null && !u.isRole()) {  // phóng viên
                req.getSession().setAttribute("user", u);
                resp.sendRedirect(req.getContextPath() + "/reporter/news");
            } else {
                req.setAttribute("error", "Sai tài khoản hoặc bạn không phải phóng viên");
                req.getRequestDispatcher("/reporter/login.jsp").forward(req, resp);
            }
        } catch (Exception e) {
            e.printStackTrace();
            req.setAttribute("error", "Lỗi đăng nhập: " + e.getMessage());
            req.getRequestDispatcher("/reporter/login.jsp").forward(req, resp);
        }
    }
}
