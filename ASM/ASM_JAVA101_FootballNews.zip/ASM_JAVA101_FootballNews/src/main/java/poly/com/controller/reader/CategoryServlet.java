package poly.com.controller.reader;

import java.io.IOException;
import java.util.List;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import poly.com.dao.CategoryDao;
import poly.com.dao.NewsDao;
import poly.com.model.Category;
import poly.com.model.News;

@WebServlet("/category")
public class CategoryServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        String id = req.getParameter("id");
        if (id == null) { resp.sendRedirect(req.getContextPath() + "/home"); return; }

        try {
            CategoryDao cdao = new CategoryDao();
            NewsDao ndao = new NewsDao();

            List<Category> cates = cdao.findAll();
            List<News> list = ndao.findByCategory(id);

            req.setAttribute("cates", cates);
            req.setAttribute("list", list);
            req.setAttribute("cateId", id);

            req.getRequestDispatcher("/reader/category.jsp").forward(req, resp);
        } catch (Exception e) {
            e.printStackTrace();
            resp.sendError(500);
        }
    }
}
