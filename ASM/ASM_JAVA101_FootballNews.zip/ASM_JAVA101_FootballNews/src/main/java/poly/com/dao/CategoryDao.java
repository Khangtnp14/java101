package poly.com.dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import poly.com.model.Category;

public class CategoryDao extends ConnectDao {

    public CategoryDao() { super(); }

    public List<Category> findAll() throws Exception {
        List<Category> list = new ArrayList<>();
        String sql = "SELECT Id, Name FROM CATEGORIES ORDER BY Name";
        try (PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                list.add(new Category(rs.getString("Id"), rs.getString("Name")));
            }
        }
        return list;
    }
}
