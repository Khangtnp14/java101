package poly.com.dao;

import java.sql.*;
import poly.com.model.User;

public class UserDao extends ConnectDao {

    public UserDao() { super(); }

    public User login(String id, String password) throws Exception {
        String sql = "SELECT * FROM USERS WHERE Id=? AND Password=?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, id);
            ps.setString(2, password);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    User u = new User();
                    u.setId(rs.getString("Id"));
                    u.setPassword(rs.getString("Password"));
                    u.setFullname(rs.getString("Fullname"));
                    u.setBirthday(rs.getDate("Birthday"));
                    u.setGender(rs.getBoolean("Gender"));
                    u.setMobile(rs.getString("Mobile"));
                    u.setEmail(rs.getString("Email"));
                    u.setRole(rs.getBoolean("Role"));
                    return u;
                }
            }
        }
        return null;
    }
}
