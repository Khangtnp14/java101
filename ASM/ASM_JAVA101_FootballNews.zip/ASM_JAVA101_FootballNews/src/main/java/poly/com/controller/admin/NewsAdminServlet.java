package poly.com.controller.admin;

import java.io.File;
import java.io.IOException;
import java.nio.file.Paths;
import java.util.List;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import poly.com.dao.CategoryDao;
import poly.com.dao.NewsDao;
import poly.com.dao.NewsletterDao;
import poly.com.model.Category;
import poly.com.model.News;
import poly.com.model.User;
import poly.com.service.MailService;

@MultipartConfig
@WebServlet("/admin/news")
public class NewsAdminServlet extends HttpServlet {

    private static final String VIEW = "/admin/news-list.jsp";

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        // CHECK ADMIN LOGIN
        User user = (User) req.getSession().getAttribute("user");
        if (user == null || !user.isRole()) {
            resp.sendRedirect(req.getContextPath() + "/login");
            return;
        }

        String deleteId = req.getParameter("deleteId");
        String editId   = req.getParameter("editId");

        NewsDao ndao = new NewsDao();
        CategoryDao cdao = new CategoryDao();

        try {
            if (deleteId != null) {
                int id = Integer.parseInt(deleteId);
                ndao.delete(id);
                resp.sendRedirect(req.getContextPath() + "/admin/news");
                return;
            }

            List<News> list = ndao.findAll();
            req.setAttribute("list", list);

            List<Category> cates = cdao.findAll();
            req.setAttribute("cates", cates);

            News form = null;
            if (editId != null) {
                int id = Integer.parseInt(editId);
                form = ndao.findById(id);
            }
            if (form == null) form = new News();

            req.setAttribute("form", form);
            req.getRequestDispatcher(VIEW).forward(req, resp);

        } catch (Exception e) {
            e.printStackTrace();
            resp.sendError(500);
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        // CHECK ADMIN LOGIN
        User user = (User) req.getSession().getAttribute("user");
        if (user == null || !user.isRole()) {
            resp.sendRedirect(req.getContextPath() + "/login");
            return;
        }

        req.setCharacterEncoding("UTF-8");

        String sid        = req.getParameter("id");
        String title      = req.getParameter("title");
        String content    = req.getParameter("content");
        String categoryId = req.getParameter("categoryId");
        String home       = req.getParameter("home");

        String authorId = user.getId();

        String imageName = req.getParameter("imageCurrent");
        Part imagePart = req.getPart("imageFile");
        if (imagePart != null && imagePart.getSize() > 0) {
            String fileName = Paths.get(imagePart.getSubmittedFileName()).getFileName().toString();
            String uploadDir = req.getServletContext().getRealPath("/uploads");

            File dir = new File(uploadDir);
            if (!dir.exists()) dir.mkdirs();

            File savedFile = new File(dir, fileName);
            imagePart.write(savedFile.getAbsolutePath());

            imageName = "uploads/" + fileName;
        }

        News n = new News();
        n.setTitle(title);
        n.setContent(content);
        n.setImage(imageName);
        n.setCategoryId(categoryId);
        n.setAuthor(authorId);
        n.setHome("on".equals(home));

        NewsDao dao = new NewsDao();

        try {
            if (sid == null || sid.isBlank() || "0".equals(sid)) {
                dao.insert(n);
                req.getSession().setAttribute("msg", "Thêm tin mới thành công");

                try {
                    NewsletterDao nd = new NewsletterDao();
                    List<String> emails = nd.findEnabledEmails();
                    new MailService().sendNewsToSubscribers(n, emails);
                } catch (Exception ex) {
                    ex.printStackTrace();
                }

            } else {
                n.setId(Integer.parseInt(sid));
                dao.update(n);
                req.getSession().setAttribute("msg", "Cập nhật tin thành công");
            }

            resp.sendRedirect(req.getContextPath() + "/admin/news");

        } catch (Exception e) {
            e.printStackTrace();
            req.setAttribute("error", "Lỗi khi lưu dữ liệu: " + e.getMessage());
            req.setAttribute("form", n);
            try {
                req.setAttribute("list", dao.findAll());
                req.setAttribute("cates", new CategoryDao().findAll());
            } catch (Exception ignored) {}
            req.getRequestDispatcher(VIEW).forward(req, resp);
        }
    }
}
