package poly.com.controller.reader;

import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import poly.com.dao.NewsletterDao;

@WebServlet({"/newsletter", "/newsletter/unsubscribe"})
public class NewsletterServlet extends HttpServlet {

    private final NewsletterDao dao = new NewsletterDao();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        // Không cho GET làm gì cả -> quay về home
        resp.sendRedirect(req.getContextPath() + "/home");
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        req.setCharacterEncoding("UTF-8");
        resp.setCharacterEncoding("UTF-8");

        String uri = req.getRequestURI();
        String email = req.getParameter("email");

        if (email == null) email = "";
        email = email.trim().toLowerCase();

        if (email.isBlank()) {
            req.getSession().setAttribute("msg", "Email không hợp lệ.");
            resp.sendRedirect(req.getContextPath() + "/home");
            return;
        }

        try {
            if (uri.endsWith("/unsubscribe")) {
                dao.unsubscribe(email);
                req.getSession().setAttribute("msg", "Đã hủy đăng ký nhận bản tin: " + email);
            } else {
                dao.subscribe(email);
                req.getSession().setAttribute("msg", "Đăng ký nhận bản tin thành công: " + email);
            }
        } catch (Exception e) {
            e.printStackTrace();
            req.getSession().setAttribute("msg", "Lỗi newsletter: " + e.getMessage());
        }

        // PRG - tránh F5 bị gửi lại form
        resp.sendRedirect(req.getContextPath() + "/home");
    }
}
