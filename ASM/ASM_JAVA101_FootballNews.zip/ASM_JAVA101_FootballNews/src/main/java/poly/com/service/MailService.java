package poly.com.service;

import java.util.List;
import java.util.Properties;
import jakarta.mail.*;
import jakarta.mail.internet.*;

import poly.com.model.News;

public class MailService {

    private Session createSession() {
        Properties p = new Properties();
        p.put("mail.smtp.auth", "true");
        p.put("mail.smtp.starttls.enable", "true");
        p.put("mail.smtp.ssl.protocols", "TLSv1.2");
        p.put("mail.smtp.host", "smtp.gmail.com");
        p.put("mail.smtp.port", "587");

        return Session.getInstance(p, new Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(
                        "trannguyenphuckhang2@gmail.com",
                        "uajd wqrt nzjq qcdh"
                );
            }
        });
    }

    public void sendNewsToSubscribers(News n, List<String> emails) throws Exception {
        if (emails == null || emails.isEmpty()) return;

        Session s = createSession();
        Message msg = new MimeMessage(s);
        msg.setFrom(new InternetAddress("trannguyenphuckhang2@gmail.com"));
        msg.setSubject("[POLY FOOTBALL] Bản tin mới: " + n.getTitle());

        String body = "<h3>" + n.getTitle() + "</h3>"
                + "<p>" + n.getContent() + "</p>";

        msg.setContent(body, "text/html; charset=UTF-8");

        for (String e : emails) {
            msg.setRecipients(Message.RecipientType.TO, InternetAddress.parse(e));
            Transport.send(msg);
        }
    }
}
