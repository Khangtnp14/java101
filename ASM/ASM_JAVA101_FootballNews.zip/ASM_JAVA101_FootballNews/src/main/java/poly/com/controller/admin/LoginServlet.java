package poly.com.controller.admin;

import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import poly.com.dao.UserDao;
import poly.com.model.User;

@WebServlet("/admin/login")
public class LoginServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        req.getRequestDispatcher("/admin/login.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        String id = req.getParameter("id");
        String pw = req.getParameter("password");

        try {
            UserDao dao = new UserDao();
            User u = dao.login(id, pw);
            if (u != null && u.isRole()) {  // admin
                req.getSession().setAttribute("user", u);
                resp.sendRedirect(req.getContextPath() + "/admin/news");
            } else {
                req.setAttribute("error", "Sai tài khoản hoặc bạn không phải Admin");
                req.getRequestDispatcher("/admin/login.jsp").forward(req, resp);
            }
        } catch (Exception e) {
            e.printStackTrace();
            req.setAttribute("error", "Lỗi đăng nhập: " + e.getMessage());
            req.getRequestDispatcher("/admin/login.jsp").forward(req, resp);
        }
    }
}
