package poly.com.filter;

import java.io.IOException;
import jakarta.servlet.*;
import jakarta.servlet.http.*;

import poly.com.model.User;

public class AuthFilter implements Filter {

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {

        HttpServletRequest req  = (HttpServletRequest) request;
        HttpServletResponse resp = (HttpServletResponse) response;

        String uri = req.getRequestURI();

        // Bỏ qua cho trang login/logout admin
        if (uri.startsWith(req.getContextPath() + "/admin/login")
                || uri.startsWith(req.getContextPath() + "/admin/logout")) {
            chain.doFilter(request, response);
            return;
        }

        HttpSession session = req.getSession(false);
        User user = (session == null) ? null : (User) session.getAttribute("user");

        // user null hoặc role=false => không phải admin
        if (user == null || !user.isRole()) {
            resp.sendRedirect(req.getContextPath() + "/admin/login");
            return;
        }

        chain.doFilter(request, response);
    }
}
