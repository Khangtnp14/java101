package poly.com.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class NewsletterDao extends ConnectDao {

    // Đăng ký: nếu có rồi thì Enabled=1, chưa có thì insert
    public void subscribe(String email) {
        // 1) update trước
        String sqlUpdate = "UPDATE NEWSLETTERS SET Enabled = 1 WHERE Email = ?";
        try (PreparedStatement ps = conn.prepareStatement(sqlUpdate)) {
            ps.setString(1, email);
            int updated = ps.executeUpdate();
            if (updated > 0) return;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        // 2) nếu update không có dòng -> insert
        String sqlInsert = "INSERT INTO NEWSLETTERS(Email, Enabled) VALUES(?, 1)";
        try (PreparedStatement ps = conn.prepareStatement(sqlInsert)) {
            ps.setString(1, email);
            ps.executeUpdate();
        } catch (Exception e) {
            // nếu email đã tồn tại (race condition) -> update lại
            try (PreparedStatement ps2 = conn.prepareStatement(sqlUpdate)) {
                ps2.setString(1, email);
                ps2.executeUpdate();
            } catch (Exception ex2) {
                throw new RuntimeException(ex2);
            }
        }
    }

    // Hủy đăng ký: Enabled = 0
    public void unsubscribe(String email) {
        String sql = "UPDATE NEWSLETTERS SET Enabled = 0 WHERE Email = ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, email);
            int updated = ps.executeUpdate();

            // Nếu email chưa từng tồn tại, bạn có thể chọn INSERT enabled=0 cho “đúng nghiệp vụ”
            // (không bắt buộc). Mình để luôn cho chắc:
            if (updated == 0) {
                String insert = "INSERT INTO NEWSLETTERS(Email, Enabled) VALUES(?, 0)";
                try (PreparedStatement ps2 = conn.prepareStatement(insert)) {
                    ps2.setString(1, email);
                    ps2.executeUpdate();
                } catch (Exception ignore) {
                    // nếu đã tồn tại thì thôi
                }
            }

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    // Lấy danh sách email đang bật nhận tin để gửi mail
    public List<String> findEnabledEmails() {
        List<String> list = new ArrayList<>();
        String sql = "SELECT Email FROM NEWSLETTERS WHERE Enabled = 1";
        try (PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                list.add(rs.getString("Email"));
            }

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return list;
    }
}
