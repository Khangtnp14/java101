package poly.com.controller.auth;

import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import poly.com.dao.UserDao;
import poly.com.model.User;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        req.getRequestDispatcher("/auth/login.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        req.setCharacterEncoding("UTF-8");

        String id = req.getParameter("id");
        String pw = req.getParameter("password");

        try {
            UserDao dao = new UserDao();
            User u = dao.login(id, pw);

            if (u == null) {
                req.setAttribute("error", "Sai tài khoản hoặc mật khẩu");
                req.getRequestDispatcher("/auth/login.jsp").forward(req, resp);
                return;
            }

            // Lưu session
            req.getSession().setAttribute("user", u);

            // Redirect đúng trang theo role
            if (u.isRole()) {
                resp.sendRedirect(req.getContextPath() + "/admin/news");
            } else {
                resp.sendRedirect(req.getContextPath() + "/reporter/news");
            }

        } catch (Exception e) {
            e.printStackTrace();
            req.setAttribute("error", "Lỗi đăng nhập: " + e.getMessage());
            req.getRequestDispatcher("/auth/login.jsp").forward(req, resp);
        }
    }
}
