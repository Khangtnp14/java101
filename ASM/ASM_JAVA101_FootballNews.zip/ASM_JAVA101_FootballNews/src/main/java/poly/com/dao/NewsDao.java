package poly.com.dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import poly.com.model.News;

public class NewsDao extends ConnectDao {

    public NewsDao() { super(); }

    private News read(ResultSet rs) throws Exception {
        News n = new News();
        n.setId(rs.getInt("Id"));
        n.setTitle(rs.getString("Title"));
        n.setContent(rs.getString("Content"));
        n.setImage(rs.getString("Image"));
        n.setPostedDate(rs.getDate("PostedDate"));
        n.setAuthor(rs.getString("Author"));
        n.setViewCount(rs.getInt("ViewCount"));
        n.setCategoryId(rs.getString("CategoryId"));
        n.setHome(rs.getBoolean("Home"));
        return n;
    }

    // Reader
    public List<News> findHome() throws Exception {
        String sql = "SELECT TOP 5 * FROM NEWS WHERE Home = 1 ORDER BY PostedDate DESC";
        List<News> list = new ArrayList<>();
        try (PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) list.add(read(rs));
        }
        return list;
    }

    public List<News> findHotTop5() throws Exception {
        String sql = "SELECT TOP 5 * FROM NEWS ORDER BY ViewCount DESC";
        List<News> list = new ArrayList<>();
        try (PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) list.add(read(rs));
        }
        return list;
    }

    public List<News> findLatestTop5() throws Exception {
        String sql = "SELECT TOP 5 * FROM NEWS ORDER BY PostedDate DESC";
        List<News> list = new ArrayList<>();
        try (PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) list.add(read(rs));
        }
        return list;
    }

    public List<News> findByCategory(String cateId) throws Exception {
        String sql = "SELECT * FROM NEWS WHERE CategoryId=? ORDER BY PostedDate DESC";
        List<News> list = new ArrayList<>();
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, cateId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) list.add(read(rs));
            }
        }
        return list;
    }

    public List<News> findRelated(int excludeId, String cateId) throws Exception {
        String sql = "SELECT TOP 5 * FROM NEWS WHERE CategoryId=? AND Id<>? ORDER BY PostedDate DESC";
        List<News> list = new ArrayList<>();
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, cateId);
            ps.setInt(2, excludeId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) list.add(read(rs));
            }
        }
        return list;
    }

    public News findById(int id) throws Exception {
        String sql = "SELECT * FROM NEWS WHERE Id=?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return read(rs);
            }
        }
        return null;
    }

    public void increaseView(int id) throws Exception {
        String sql = "UPDATE NEWS SET ViewCount = ViewCount + 1 WHERE Id=?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            ps.executeUpdate();
        }
    }

    // Admin/Reporter list
    public List<News> findAll() throws Exception {
        String sql = "SELECT * FROM NEWS ORDER BY Id DESC";
        List<News> list = new ArrayList<>();
        try (PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) list.add(read(rs));
        }
        return list;
    }

    public List<News> findByAuthor(String authorId) throws Exception {
        String sql = "SELECT * FROM NEWS WHERE Author=? ORDER BY Id DESC";
        List<News> list = new ArrayList<>();
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, authorId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) list.add(read(rs));
            }
        }
        return list;
    }

    public void insert(News n) throws Exception {
        String sql = "INSERT INTO NEWS(Title,Content,Image,Author,CategoryId,Home) "
                   + "VALUES(?,?,?,?,?,?)";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, n.getTitle());
            ps.setString(2, n.getContent());
            ps.setString(3, n.getImage());
            ps.setString(4, n.getAuthor());
            ps.setString(5, n.getCategoryId());
            ps.setBoolean(6, n.isHome());
            ps.executeUpdate();
        }
    }

    public void update(News n) throws Exception {
        String sql = "UPDATE NEWS SET Title=?,Content=?,Image=?,CategoryId=?,Home=? WHERE Id=?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, n.getTitle());
            ps.setString(2, n.getContent());
            ps.setString(3, n.getImage());
            ps.setString(4, n.getCategoryId());
            ps.setBoolean(5, n.isHome());
            ps.setInt(6, n.getId());
            ps.executeUpdate();
        }
    }

    public void delete(int id) throws Exception {
        String sql = "DELETE FROM NEWS WHERE Id=?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            ps.executeUpdate();
        }
    }
}
