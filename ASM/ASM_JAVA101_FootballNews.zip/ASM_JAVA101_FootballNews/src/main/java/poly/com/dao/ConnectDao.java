package poly.com.dao;

import java.sql.Connection;
import java.sql.DriverManager;

public class ConnectDao {
    protected static Connection conn;

    public ConnectDao() {
        if (conn != null) return;
        try {
            String url = "jdbc:sqlserver://localhost:1433;databaseName=ASM_JAVA101;encrypt=false";
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            conn = DriverManager.getConnection(url, "sa", ""); // sửa password nếu khác
            System.out.println("[DB] Kết nối ASM_JAVA101 OK");
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}
