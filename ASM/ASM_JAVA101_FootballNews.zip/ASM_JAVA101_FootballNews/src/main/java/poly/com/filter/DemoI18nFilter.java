package poly.com.filter;

import java.io.IOException;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebFilter;
import jakarta.servlet.http.HttpFilter;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebFilter("/demo/*")
public class DemoI18nFilter extends HttpFilter {
    @Override
    protected void doFilter(HttpServletRequest req, HttpServletResponse resp, FilterChain chain)
            throws IOException, ServletException {

        String lang = req.getParameter("lang");
        if (lang != null) {
            lang = lang.trim().toLowerCase();
            if ("vi".equals(lang) || "en".equals(lang)) {
                req.getSession().setAttribute("lang", lang);
            }
        }
        chain.doFilter(req, resp);
    }
}
