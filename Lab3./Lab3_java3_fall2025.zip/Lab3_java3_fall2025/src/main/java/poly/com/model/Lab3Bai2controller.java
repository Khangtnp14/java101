package poly.com.model;

import java.io.IOException;
import java.util.List;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
@WebServlet("/Lab3bai2")
public class Lab3Bai2controller extends HttpServlet{
@Override
protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	// TODO Auto-generated method stub
	List<Country> list= List.of(new Country("VN","Viet Nam"),new Country("US","Mỹ"),new Country("CN","China"));
	req.setAttribute("Countries",list);	
	req.getRequestDispatcher("Lab3bai2.jsp").forward(req, resp); 
	
	
}
}
